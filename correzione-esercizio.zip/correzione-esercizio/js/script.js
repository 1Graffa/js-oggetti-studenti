// Oggetti
// - Creare un oggetto che descriva uno studente
// con le seguenti proprietà: nome, cognome e età.
// Stampare a schermo attraverso il for in tutte le
// proprietà.
// - Creare un array di oggetti di studenti. Ciclare su
// tutti gli studenti e stampare per ognuno nome e
// cognome
// - Dare la possibilità all’utente attraverso 3 prompt
// di aggiungere un nuovo oggetto studente
// inserendo nell’ordine: nome, cognome e età.

// OGGETTO STUDENTE
// var studente = {
//   'nome' : 'mario',
//   'cognome' : 'rossi',
//   'eta' : 18
// };
// console.log(studente);

// STAMPARE TUTTE LE PROPRIETA
// for (var k in studente) {
//   console.log(k,': ',studente[k]);
// }

// ARRAY STUDENTI
var studenti = [
  {
    'nome' : 'mario',
    'cognome' : 'rossi',
    'eta' : 18
  },
  {
    'nome' : 'giuseppe',
    'cognome' : 'verdi',
    'eta' : 21
  },
  {
    'nome' : 'marco',
    'cognome' : 'bianchi',
    'eta' : 20
  }
];

// NOME E COGNOME DI OGNI STUDENTE
// for (var i = 0; i < studenti.length; i++) {
//   console.log(studenti[i].nome,' ',studenti[i].cognome);
// }

// INSERIMENTO NUOVO STUDENTE
var nomeInput = prompt('inserisci nome');
var cognomeInput = prompt('inserisci cognome');
var etaInput = parseInt(prompt('inserisci età'));

var studenteInput ={
  'nome' : nomeInput,
  'cognome' : cognomeInput,
  'eta' : etaInput
};

studenti.push(studenteInput);
console.log(studenti);
